
package classes;

public class ContaCorrente {
    // Final aprendido analisando o codigo da classe Cao.java
    // Numero da Conta e CPF nao mudarao, portanto, recebem indicador final
    
    private final int numConta;
    private final String cpf;
    private double saldo;

    public ContaCorrente(int numConta, String cpf, double saldo){
        this.numConta = numConta;
        this.cpf = cpf;
        this.saldo = saldo;
    }
    
    public int getNumConta() {
        return numConta;
    }
    
    public String getCpf() {
        return cpf;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public void saque(double valorSaque){
        saldo -= valorSaque*1.005;
    }
    
    public void deposito(double valorDeposito){
        saldo += valorDeposito;
    }
    
    public void exibeConta(){
        System.out.println("=============================");
        System.out.println("Numero da Conta: " + numConta);
        System.out.println("CPF do titular: " + cpf);
        System.out.println("Saldo da Conta: " + saldo);        
        System.out.println("=============================\n");

    }
}

