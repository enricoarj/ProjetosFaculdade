
package classes;

import java.util.ArrayList;


public class Banco {
    private final ArrayList<ContaCorrente> correntistas;
    
    public Banco(){
        this.correntistas = new ArrayList<>();
    }
    
    public void abrirConta(ContaCorrente cliente){
        correntistas.add(cliente);
    }
    
    public void encerrarConta(int indice){
        correntistas.remove(indice);
    }
    
    public ContaCorrente getCorrentista(String cpfDesejado){
        for(int i = 0; i < correntistas.size(); i ++){
            if(cpfDesejado.equals(correntistas.get(i).getCpf())){
                correntistas.get(i).exibeConta();
                return correntistas.get(i);
            }
        }
        return null;
    }
    
    public void exibeCorrentistas(){
        if(!correntistas.isEmpty()){
            System.out.println("=============================");
            System.out.println("Exibindo correntistas...");
            System.out.println("=============================\n");

            for(int i = 0; i < correntistas.size(); i ++){
                correntistas.get(i).exibeConta();
            }
        }else{
            System.out.println("\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");            
            System.out.println("Nao ha nenhuma conta corrente registrada.");            
            System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");            
        }
    }
}
