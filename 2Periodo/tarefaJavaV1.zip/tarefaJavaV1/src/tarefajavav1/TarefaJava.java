package tarefajavav1;

import classes.Banco;
import classes.ContaCorrente;

public class TarefaJava{

    public static void main(String[] args) {
        
        //Criacao das contas
        ContaCorrente c1 = new ContaCorrente(1, "000", 0);
        ContaCorrente c2 = new ContaCorrente(2, "111", 123);
        ContaCorrente c3 = new ContaCorrente(3, "222", 1526);
        
        //Criacao do banco
        Banco banco1 = new Banco();
        
        //Teste antes da adicao das contas
        banco1.exibeCorrentistas();
        
        //Adicao das contas
        banco1.abrirConta(c1);
        banco1.abrirConta(c2);
        banco1.abrirConta(c3);
        
        //Teste pos adicao das contas
        banco1.exibeCorrentistas();

        //Alteracao de saldos
        
        System.out.println("\nMOMENTO ALTERACOES\n");
        banco1.getCorrentista("111").deposito(1000.86);
        banco1.getCorrentista("222").deposito(3262.23);
        banco1.getCorrentista("333").deposito(23.25);  
        banco1.exibeCorrentistas();

        banco1.getCorrentista("111").saque(10);
        banco1.getCorrentista("222").saque(100);
        
        banco1.exibeCorrentistas();

        banco1.encerrarConta(1);
        banco1.exibeCorrentistas();

    }
}
